-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2022 at 09:58 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatbot_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `interaction`
--

CREATE TABLE `interaction` (
  `sno` int(11) NOT NULL,
  `questions` varchar(100) NOT NULL,
  `response` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `interaction`
--

INSERT INTO `interaction` (`sno`, `questions`, `response`) VALUES
(1, 'hi', 'Hi how can I help you ?'),
(2, 'hello', 'Hi how can I help you ?'),
(3, 'what is your name', 'My name is Dutchman'),
(4, 'i want to know about college', 'To know about our college you can use our about Us section in navigation bar'),
(5, 'does college has its own website', 'Of course yes !.\r\nYou can  use our HOME section in navigation bar\r\n, which redirects you to our coll'),
(6, 'what are the scholarships available in our college', 'There are many scholarships that students can avail them\r\n1.SSP\r\n2.NSP\r\n3.Labour dept\r\n4.UVCE Alumin'),
(7, 'i want to know about uvce\r\n', 'To know about our college you can use our about Us..'),
(8, 'when dis uvce started', 'UVCE was started in 1917'),
(9, 'what is the college starting time', 'College usually starts at 8:50 to 2:20\r\nif you have labs then it may extend up to 5.'),
(10, 'is saturday holiday in uvce', 'Yes weekends will be off in UVCE \r\nsometimes they will take labs for some batches on satrurday too..');

-- --------------------------------------------------------

--
-- Table structure for table `student_messages`
--

CREATE TABLE `student_messages` (
  `slno` int(11) NOT NULL,
  `student_message` varchar(50) NOT NULL,
  `bot_message` varchar(200) NOT NULL,
  `time` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_messages`
--

INSERT INTO `student_messages` (`slno`, `student_message`, `bot_message`, `time`) VALUES
(1, 'hi', 'Hi how can I help you ?', '11:09'),
(2, 'what is your name', 'My name is Dutchman', '11:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `interaction`
--
ALTER TABLE `interaction`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `student_messages`
--
ALTER TABLE `student_messages`
  ADD PRIMARY KEY (`slno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `interaction`
--
ALTER TABLE `interaction`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `student_messages`
--
ALTER TABLE `student_messages`
  MODIFY `slno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
